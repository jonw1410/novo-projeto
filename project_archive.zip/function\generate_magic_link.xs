// This function generates a magic token with a 60 minute expiration date.
function generate_magic_link {
  input {
    email email?
  }

  stack {
    precondition ($input.email != null) {
      error = "email is required but was not suppiled. "
    }
  
    db.query user {
      where = $db.user.email == $input.email
      return = {type: "single"}
    } as $user
  
    precondition ($user != null) {
      error_type = "notfound"
      error = "No user found for that email."
    }
  
    security.create_password {
      character_count = 12
      require_lowercase = true
      require_uppercase = true
      require_digit = true
      require_symbol = false
      symbol_whitelist = ""
    } as $token
  
    var $magic_link {
      value = {}
        |set:"token":$token
        |set:"expiration":(now
          |add_secs_to_timestamp:($env.magic_link_expiry_time|to_int)
        )
        |set:"used":false
    }
  
    var $jwt_payload {
      value = {}
        |set:"user_id":($user|get:"id":0)
        |set:"magic_token":($magic_link|get:"token":null)
    }
  
    db.edit user {
      field_name = "id"
      field_value = $user|get:"id":0
      enforce_hidden_fields = false
      data = {magic_link: $magic_link}
    } as $updated_magic_link
  
    security.jwe_encode_legacy {
      payload = $jwt_payload
      audience = "Xano"
      key = $env.magic_jwt_secret
      key_algorithm = "A256KW"
      content_algorithm = "A256CBC-HS512"
    } as $jwt
  
    var $magic_link {
      value = $env.magic_link_redirect_uri|concat:$jwt:"?token="
    }
  }

  response = $magic_link
  tags = ["xano:quick-start"]
  guid = "mlWa8e5Zbz28OhrRbhJdmPIpbrE"
}